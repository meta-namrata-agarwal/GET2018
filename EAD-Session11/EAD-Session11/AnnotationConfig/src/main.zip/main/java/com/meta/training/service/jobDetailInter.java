package com.meta.training.service;

public interface jobDetailInter {

}
